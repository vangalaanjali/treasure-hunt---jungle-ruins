using UnityEngine;

public enum CollectibleType { Coin, Key, Clue }

// Attach to a root object with a trigger collider. Coins add score, keys unlock the
// treasure door, clues show a hint message.
public class Collectible : MonoBehaviour
{
    public CollectibleType type = CollectibleType.Coin;
    public int points = 10;
    [TextArea] public string message = "";
    public float spinSpeed = 120f;
    public float bobHeight = 0.15f;
    public float bobSpeed = 2f;

    private Vector3 startPos;

    void Start()
    {
        startPos = transform.position;
    }

    void Update()
    {
        transform.Rotate(Vector3.up, spinSpeed * Time.deltaTime, Space.World);
        transform.position = startPos + Vector3.up * (Mathf.Sin(Time.time * bobSpeed) * bobHeight);
    }

    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;

        GameManager manager = GameManager.Instance;
        if (manager == null || !manager.IsPlaying) return;

        switch (type)
        {
            case CollectibleType.Coin: manager.AddScore(points); break;
            case CollectibleType.Key:  manager.AddScore(points); manager.AddKey(); break;
            case CollectibleType.Clue: manager.AddScore(points); manager.AddClue(message); break;
        }

        Destroy(gameObject);
    }
}
