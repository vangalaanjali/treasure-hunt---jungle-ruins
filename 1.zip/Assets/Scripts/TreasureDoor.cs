using System.Collections;
using UnityEngine;

// Put on a trigger zone in front of the stone door. Assign the door mesh to "door".
// The door slides down into the floor once the player has the required key(s).
public class TreasureDoor : MonoBehaviour
{
    public Transform door;
    public int requiredKeys = 1;
    public float openDistance = 4.2f;
    public float openDuration = 2f;

    private bool opened;
    private float lastLockedMessage = -10f;

    void OnTriggerEnter(Collider other) { Check(other); }
    void OnTriggerStay(Collider other) { Check(other); }

    private void Check(Collider other)
    {
        if (opened || !other.CompareTag("Player")) return;

        GameManager gm = GameManager.Instance;
        if (gm == null || !gm.IsPlaying) return;

        if (gm.Keys >= requiredKeys)
        {
            opened = true;
            gm.ShowMessage("Door unlocked!", 3f);
            StartCoroutine(OpenDoor());
        }
        else if (Time.time - lastLockedMessage > 3f)
        {
            lastLockedMessage = Time.time;
            gm.ShowMessage("The door is locked. Find the key!", 3f);
        }
    }

    private IEnumerator OpenDoor()
    {
        Vector3 start = door.position;
        Vector3 end = start + Vector3.down * openDistance;
        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / openDuration;
            door.position = Vector3.Lerp(start, end, Mathf.SmoothStep(0f, 1f, t));
            yield return null;
        }
    }
}
