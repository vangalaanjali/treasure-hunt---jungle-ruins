using UnityEngine;

// Treasure Hunt - Jungle Ruin
// Attach to the Player (Capsule with Rigidbody). Walkable ground must be tagged "Ground".
// Uses Unity's legacy Input Manager (Project Settings > Player > Active Input Handling = Both / Old).
[RequireComponent(typeof(Rigidbody))]
public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float jumpForce = 6f;
    public float turnSpeed = 14f;
    public float fallDeathY = -15f;

    private Rigidbody rb;
    private bool grounded;
    private bool jumpRequested;

    // Works on both Unity 6 (linearVelocity) and older versions (velocity)
    private Vector3 Velocity
    {
        get
        {
#if UNITY_6000_0_OR_NEWER
            return rb.linearVelocity;
#else
            return rb.velocity;
#endif
        }
        set
        {
#if UNITY_6000_0_OR_NEWER
            rb.linearVelocity = value;
#else
            rb.velocity = value;
#endif
        }
    }

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.Continuous;

        // Frictionless material so the player never sticks to walls or pillars
        Collider c = GetComponent<Collider>();
        if (c != null)
        {
#if UNITY_6000_0_OR_NEWER
            PhysicsMaterial pm = new PhysicsMaterial("NoFriction");
            pm.frictionCombine = PhysicsMaterialCombine.Minimum;
#else
            PhysicMaterial pm = new PhysicMaterial("NoFriction");
            pm.frictionCombine = PhysicMaterialCombine.Minimum;
#endif
            pm.dynamicFriction = 0f;
            pm.staticFriction = 0f;
            c.sharedMaterial = pm;
        }
    }

    void Update()
    {
        if (Input.GetButtonDown("Jump"))
            jumpRequested = true;

        // Falling out of the world counts as falling into a pit
        if (transform.position.y < fallDeathY && GameManager.Instance != null)
            GameManager.Instance.GameOver("You fell into the ravine!");
    }

    void FixedUpdate()
    {
        GameManager gm = GameManager.Instance;
        if (gm != null && !gm.IsPlaying)
        {
            Velocity = new Vector3(0f, Velocity.y, 0f);
            jumpRequested = false;
            grounded = false;
            return;
        }

        float x = Input.GetAxisRaw("Horizontal");
        float z = Input.GetAxisRaw("Vertical");
        Vector3 input = new Vector3(x, 0f, z);
        Vector3 move = input.normalized * moveSpeed;

        Velocity = new Vector3(move.x, Velocity.y, move.z);

        // Face the direction of travel
        if (input.sqrMagnitude > 0.01f)
        {
            Quaternion target = Quaternion.LookRotation(input.normalized);
            rb.MoveRotation(Quaternion.Slerp(rb.rotation, target, turnSpeed * Time.fixedDeltaTime));
        }

        if (jumpRequested && grounded)
        {
            Velocity = new Vector3(Velocity.x, 0f, Velocity.z);
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }

        jumpRequested = false;
        grounded = false; // re-set to true by the collision callbacks below
    }

    void OnCollisionEnter(Collision collision) { CheckGround(collision); }
    void OnCollisionStay(Collision collision) { CheckGround(collision); }

    private void CheckGround(Collision collision)
    {
        if (!collision.gameObject.CompareTag("Ground")) return;
        foreach (ContactPoint contact in collision.contacts)
        {
            if (contact.normal.y > 0.5f) // standing on top, not touching a wall
            {
                grounded = true;
                return;
            }
        }
    }
}
