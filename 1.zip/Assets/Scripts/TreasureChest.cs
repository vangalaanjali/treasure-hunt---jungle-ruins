using UnityEngine;

// Put on the treasure chest root (with a trigger collider). Reaching it wins the level.
public class TreasureChest : MonoBehaviour
{
    public int bonusPoints = 100;

    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        if (GameManager.Instance != null)
            GameManager.Instance.Victory(bonusPoints);
    }
}
