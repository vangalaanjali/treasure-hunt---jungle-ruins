using UnityEngine;

// Put on pits, trap zones and the kill plane (collider with Is Trigger enabled).
public class Hazard : MonoBehaviour
{
    public string message = "You fell into a trap!";

    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        if (GameManager.Instance != null)
            GameManager.Instance.GameOver(message);
    }
}
