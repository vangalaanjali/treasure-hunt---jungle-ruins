using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public enum GameState { Playing, GameOver, Won }

// Tracks score, keys, clues and game state, and draws the HUD with Unity's built-in OnGUI
// (no extra packages required).
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public int keysRequired = 1;
    public int totalClues = 2;

    public GameState State { get; private set; } = GameState.Playing;
    public bool IsPlaying { get { return State == GameState.Playing; } }
    public int Score { get; private set; }
    public int Keys { get; private set; }
    public int Clues { get; private set; }

    private string message = "";
    private string statusMain = "";
    private string statusSub = "";
    private Color statusColor = Color.white;
    private Coroutine messageRoutine;
    private GUIStyle style;

    void Awake()
    {
        Instance = this;
        Time.timeScale = 1f;
    }

    void Start()
    {
        ShowMessage("Find the key to unlock the temple door", 5f);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
            Restart();
        else if (!IsPlaying && Input.GetKeyDown(KeyCode.Return))
            Restart();
    }

    // ---------- Game events ----------

    public void AddScore(int points)
    {
        if (!IsPlaying) return;
        Score += points;
    }

    public void AddKey()
    {
        if (!IsPlaying) return;
        Keys++;
        ShowMessage("Key collected! Return to the temple door.", 4f);
    }

    public void AddClue(string text)
    {
        if (!IsPlaying) return;
        Clues++;
        ShowMessage(string.IsNullOrEmpty(text) ? "Clue found!" : text, 5f);
    }

    public void GameOver(string reason)
    {
        if (State != GameState.Playing) return;
        State = GameState.GameOver;
        statusColor = new Color(1f, 0.25f, 0.2f);
        statusMain = "GAME OVER";
        statusSub = reason + "\nPress R to restart";
        message = "";
    }

    public void Victory(int bonus)
    {
        if (State != GameState.Playing) return;
        Score += bonus;
        State = GameState.Won;
        statusColor = new Color(1f, 0.85f, 0.2f);
        statusMain = "TREASURE FOUND!";
        statusSub = "Final score: " + Score + "\nPress R to play again";
        message = "";
    }

    public void ShowMessage(string text, float seconds)
    {
        if (messageRoutine != null) StopCoroutine(messageRoutine);
        messageRoutine = StartCoroutine(MessageRoutine(text, seconds));
    }

    public void Restart()
    {
        Scene s = SceneManager.GetActiveScene();
        SceneManager.LoadScene(s.buildIndex >= 0 ? s.buildIndex : 0);
    }

    private IEnumerator MessageRoutine(string text, float seconds)
    {
        message = text;
        yield return new WaitForSeconds(seconds);
        if (IsPlaying) message = "";
    }

    // ---------- HUD ----------

    void OnGUI()
    {
        float s = Screen.height / 1080f;
        GUI.matrix = Matrix4x4.Scale(new Vector3(s, s, 1f));
        float w = Screen.width / s;

        if (!IsPlaying)
        {
            Color old = GUI.color;
            GUI.color = new Color(0f, 0f, 0f, 0.55f);
            GUI.DrawTexture(new Rect(0, 0, w, 1080f), Texture2D.whiteTexture);
            GUI.color = old;
        }

        string hud = "Score: " + Score +
                     "\nKeys: " + Keys + "/" + keysRequired +
                     "\nClues: " + Clues + "/" + totalClues;
        DrawLabel(new Rect(30, 25, 700, 200), hud, 38, TextAnchor.UpperLeft, new Color(1f, 0.92f, 0.5f));

        if (!string.IsNullOrEmpty(message))
            DrawLabel(new Rect(0, 100, w, 80), message, 44, TextAnchor.MiddleCenter, Color.white);

        if (!IsPlaying)
        {
            DrawLabel(new Rect(0, 340, w, 150), statusMain, 96, TextAnchor.MiddleCenter, statusColor);
            DrawLabel(new Rect(0, 490, w, 200), statusSub, 40, TextAnchor.UpperCenter, Color.white);
        }

        DrawLabel(new Rect(30, 1010, 1400, 50), "WASD / Arrows: Move    Space: Jump    R: Restart",
                  28, TextAnchor.LowerLeft, new Color(1f, 1f, 1f, 0.85f));
    }

    private void DrawLabel(Rect r, string text, int size, TextAnchor anchor, Color color)
    {
        if (style == null)
        {
            style = new GUIStyle(GUI.skin.label);
            style.richText = true;
            style.wordWrap = false;
        }
        style.fontSize = size;
        style.alignment = anchor;

        style.normal.textColor = Color.black; // simple outline
        GUI.Label(new Rect(r.x - 2, r.y - 2, r.width, r.height), text, style);
        GUI.Label(new Rect(r.x + 2, r.y - 2, r.width, r.height), text, style);
        GUI.Label(new Rect(r.x - 2, r.y + 2, r.width, r.height), text, style);
        GUI.Label(new Rect(r.x + 2, r.y + 2, r.width, r.height), text, style);

        style.normal.textColor = color;
        GUI.Label(r, text, style);
    }
}
