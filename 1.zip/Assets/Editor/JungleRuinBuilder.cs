using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

// Menu: Treasure Hunt > Build Jungle Ruin Level
// Creates folders, materials, the tag "Ground", the full jungle level, player, camera,
// hazards, collectibles, locked door, treasure chamber, and saves Assets/Scenes/JungleRuinLevel.unity
public static class JungleRuinBuilder
{
    const string ScenePath = "Assets/Scenes/JungleRuinLevel.unity";

    static Material mGrass, mPath, mStone, mDarkStone, mMoss, mWood, mTrunk, mLeaf, mLeaf2,
                    mGold, mRed, mKey, mScroll, mPlayer, mSkin, mHat, mChest, mRavine;

    [MenuItem("Treasure Hunt/Build Jungle Ruin Level")]
    public static void BuildLevel()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

        EnsureTag("Ground");
        EnsureFolders();
        CreateMaterials();

        EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

        Transform env = Group("Environment");
        Transform hazards = Group("Hazards");
        Transform items = Group("Collectibles");
        Transform temple = Group("Temple");

        BuildLighting();
        BuildGround(env);
        BuildBridge(env, hazards);
        BuildObstacles(env, hazards);
        BuildCourtyard(env, hazards);
        BuildTemple(temple, hazards);
        BuildJungleDecor(env);
        BuildCollectibles(items);

        GameObject gm = new GameObject("GameManager");
        gm.AddComponent<GameManager>();

        GameObject player = BuildPlayer();
        SetupCamera(player.transform);

        var scene = EditorSceneManager.GetActiveScene();
        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
        Selection.activeGameObject = player;

        EnableLegacyInput();

        EditorUtility.DisplayDialog("Treasure Hunt - Jungle Ruin",
            "Level built and saved to\n" + ScenePath + "\n\nPress Play to start!", "OK");
    }

    // ------------------------------------------------------------------ setup helpers

    static void EnsureTag(string tag)
    {
        Object[] assets = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset");
        if (assets == null || assets.Length == 0) return;
        SerializedObject tm = new SerializedObject(assets[0]);
        SerializedProperty tags = tm.FindProperty("tags");
        for (int i = 0; i < tags.arraySize; i++)
            if (tags.GetArrayElementAtIndex(i).stringValue == tag) return;
        tags.InsertArrayElementAtIndex(tags.arraySize);
        tags.GetArrayElementAtIndex(tags.arraySize - 1).stringValue = tag;
        tm.ApplyModifiedProperties();
    }

    static void EnsureFolders()
    {
        foreach (string f in new[] { "Scenes", "Scripts", "Materials", "Prefabs", "Models" })
            if (!AssetDatabase.IsValidFolder("Assets/" + f))
                AssetDatabase.CreateFolder("Assets", f);
    }

    static void EnableLegacyInput()
    {
        // The scripts use the legacy Input Manager. Switch to "Both" if the project uses only the new Input System.
        try
        {
            Object[] assets = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset");
            if (assets == null || assets.Length == 0) return;
            SerializedObject so = new SerializedObject(assets[0]);
            SerializedProperty p = so.FindProperty("activeInputHandler");
            if (p != null && p.intValue == 1)
            {
                p.intValue = 2;
                so.ApplyModifiedProperties();
                AssetDatabase.SaveAssets();
                EditorUtility.DisplayDialog("Restart Unity",
                    "Active Input Handling was switched to 'Both' so the keyboard controls work.\n" +
                    "Please restart the Unity Editor (accept its prompt), then press Play.", "OK");
            }
        }
        catch { }
    }

    static Material Mat(string name, Color c)
    {
        string path = "Assets/Materials/" + name + ".mat";
        Material m = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (m == null)
        {
            Shader s = Shader.Find("Universal Render Pipeline/Lit");
            if (s == null) s = Shader.Find("Standard");
            m = new Material(s);
            AssetDatabase.CreateAsset(m, path);
        }
        if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", c);
        if (m.HasProperty("_Color")) m.SetColor("_Color", c);
        EditorUtility.SetDirty(m);
        return m;
    }

    static void CreateMaterials()
    {
        mGrass = Mat("Grass", new Color(0.18f, 0.45f, 0.15f));
        mPath = Mat("DirtPath", new Color(0.45f, 0.33f, 0.2f));
        mStone = Mat("WeatheredStone", new Color(0.55f, 0.55f, 0.5f));
        mDarkStone = Mat("DarkStone", new Color(0.33f, 0.33f, 0.31f));
        mMoss = Mat("MossyStone", new Color(0.42f, 0.5f, 0.38f));
        mWood = Mat("Wood", new Color(0.4f, 0.26f, 0.13f));
        mTrunk = Mat("Trunk", new Color(0.3f, 0.2f, 0.1f));
        mLeaf = Mat("Leaves", new Color(0.1f, 0.38f, 0.1f));
        mLeaf2 = Mat("Leaves2", new Color(0.16f, 0.5f, 0.14f));
        mGold = Mat("Gold", new Color(1f, 0.82f, 0.1f));
        mRed = Mat("TrapRed", new Color(0.8f, 0.08f, 0.08f));
        mKey = Mat("KeyGold", new Color(1f, 0.62f, 0.1f));
        mScroll = Mat("Scroll", new Color(0.9f, 0.85f, 0.6f));
        mPlayer = Mat("Explorer", new Color(0.2f, 0.5f, 0.85f));
        mSkin = Mat("Skin", new Color(0.9f, 0.7f, 0.55f));
        mHat = Mat("Hat", new Color(0.55f, 0.38f, 0.18f));
        mChest = Mat("ChestWood", new Color(0.45f, 0.25f, 0.1f));
        mRavine = Mat("RavineBottom", new Color(0.08f, 0.1f, 0.07f));
    }

    static Transform Group(string name)
    {
        return new GameObject(name).transform;
    }

    // Creates a primitive. Position/scale are LOCAL to the parent (parents sit at the origin).
    static GameObject Prim(PrimitiveType type, string name, Vector3 pos, Vector3 scale, Material mat,
                           Transform parent, bool ground = false, bool collider = true)
    {
        GameObject go = GameObject.CreatePrimitive(type);
        go.name = name;
        go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        go.transform.localScale = scale;
        go.GetComponent<Renderer>().sharedMaterial = mat;
        if (!collider)
        {
            Collider c = go.GetComponent<Collider>();
            if (c != null) Object.DestroyImmediate(c);
        }
        if (ground) go.tag = "Ground";
        return go;
    }

    static GameObject InvisibleWall(string name, Vector3 pos, Vector3 scale, Transform parent)
    {
        GameObject go = Prim(PrimitiveType.Cube, name, pos, scale, mStone, parent);
        go.GetComponent<Renderer>().enabled = false;
        return go;
    }

    // ------------------------------------------------------------------ level sections

    static void BuildLighting()
    {
        GameObject sun = GameObject.Find("Directional Light");
        if (sun != null)
        {
            sun.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
            Light l = sun.GetComponent<Light>();
            if (l != null) { l.color = new Color(1f, 0.96f, 0.84f); l.intensity = 1.2f; }
        }
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogColor = new Color(0.45f, 0.6f, 0.45f);
        RenderSettings.fogDensity = 0.012f;
    }

    static void BuildGround(Transform env)
    {
        // Jungle entrance + forest path (z -10 .. 40)
        Prim(PrimitiveType.Cube, "JungleFloor_Forest", new Vector3(0, -0.5f, 15), new Vector3(52, 1, 50), mGrass, env, true);
        Prim(PrimitiveType.Cube, "DirtPath_Forest", new Vector3(0, 0.025f, 15), new Vector3(5, 0.05f, 50), mPath, env, true);

        // Ancient courtyard (z 53 .. 85)
        Prim(PrimitiveType.Cube, "CourtyardFloor", new Vector3(0, -0.5f, 69), new Vector3(52, 1, 32), mMoss, env, true);

        // Level boundaries (invisible)
        InvisibleWall("Boundary_Left", new Vector3(-26.5f, 5, 37.5f), new Vector3(1, 12, 95), env);
        InvisibleWall("Boundary_Right", new Vector3(26.5f, 5, 37.5f), new Vector3(1, 12, 95), env);
        InvisibleWall("Boundary_Back", new Vector3(0, 5, -10.5f), new Vector3(54, 12, 1), env);
    }

    static void BuildBridge(Transform env, Transform hazards)
    {
        // Broken bridge: three planks with jumpable gaps over a ravine (z 40 .. 53)
        float[] zs = { 42f, 46f, 50f };
        for (int i = 0; i < zs.Length; i++)
        {
            Prim(PrimitiveType.Cube, "BridgePlank_" + (i + 1), new Vector3(0, -0.2f, zs[i]), new Vector3(5, 0.4f, 2), mWood, env, true);
            Prim(PrimitiveType.Cylinder, "BridgePost_L" + i, new Vector3(-2.6f, 0.6f, zs[i]), new Vector3(0.2f, 0.6f, 0.2f), mTrunk, env, false, false);
            Prim(PrimitiveType.Cylinder, "BridgePost_R" + i, new Vector3(2.6f, 0.6f, zs[i]), new Vector3(0.2f, 0.6f, 0.2f), mTrunk, env, false, false);
        }

        Prim(PrimitiveType.Cube, "RavineBottom", new Vector3(0, -8, 46.5f), new Vector3(52, 1, 14), mRavine, env, false, false);

        GameObject pit = Prim(PrimitiveType.Cube, "PitHazard", new Vector3(0, -3, 46.5f), new Vector3(52, 2, 14), mRavine, hazards, false, true);
        pit.GetComponent<Renderer>().enabled = false;
        pit.GetComponent<Collider>().isTrigger = true;
        pit.AddComponent<Hazard>().message = "You fell into the ravine!";

        // Catch-all kill plane under the whole level
        GameObject kill = Prim(PrimitiveType.Cube, "KillZone", new Vector3(0, -12, 45), new Vector3(200, 2, 300), mRavine, hazards, false, true);
        kill.GetComponent<Renderer>().enabled = false;
        kill.GetComponent<Collider>().isTrigger = true;
        kill.AddComponent<Hazard>().message = "You fell off the ruin!";
    }

    static void BuildObstacles(Transform env, Transform hazards)
    {
        // Fallen logs across the path (jumpable)
        Prim(PrimitiveType.Cylinder, "FallenLog_1", new Vector3(0, 0.4f, 20), new Vector3(0.8f, 2.5f, 0.8f), mTrunk, env, true)
            .transform.rotation = Quaternion.Euler(0, 0, 90);
        Prim(PrimitiveType.Cylinder, "FallenLog_2", new Vector3(0.5f, 0.4f, 35), new Vector3(0.8f, 2.5f, 0.8f), mTrunk, env, true)
            .transform.rotation = Quaternion.Euler(0, 8, 90);

        // Raised stone platform on the forest path
        Prim(PrimitiveType.Cube, "StoneStep_1", new Vector3(-8, 0.4f, 28), new Vector3(3, 0.8f, 3), mStone, env, true);
        Prim(PrimitiveType.Cube, "StoneStep_2", new Vector3(-8, 0.8f, 32), new Vector3(3, 1.6f, 3), mStone, env, true);

        // Clearly marked trap zone beside the path
        MakeTrap(hazards, "TrapZone_Forest", new Vector3(6.5f, 0.15f, 30), new Vector3(3.5f, 0.3f, 3.5f), "You stepped on a trap!");
    }

    static void MakeTrap(Transform parent, string name, Vector3 pos, Vector3 scale, string msg)
    {
        GameObject t = Prim(PrimitiveType.Cube, name, pos, scale, mRed, parent, false, true);
        t.GetComponent<Collider>().isTrigger = true;
        t.AddComponent<Hazard>().message = msg;
        // spikes for readability
        for (int i = 0; i < 4; i++)
        {
            float ox = (i % 2 == 0 ? -0.25f : 0.25f);
            float oz = (i < 2 ? -0.25f : 0.25f);
            GameObject s = Prim(PrimitiveType.Cylinder, "Spike", new Vector3(ox, 1.6f, oz), new Vector3(0.15f, 1.2f, 0.15f), mDarkStone, t.transform, false, false);
        }
    }

    static void BuildCourtyard(Transform env, Transform hazards)
    {
        // Stone pillars (some broken) along both sides
        float[] zs = { 58f, 64f, 70f, 76f, 82f };
        for (int i = 0; i < zs.Length; i++)
        {
            float h = (i % 2 == 0) ? 2.5f : 1.6f;
            Prim(PrimitiveType.Cylinder, "Pillar_L" + i, new Vector3(-7, h, zs[i]), new Vector3(1.2f, h, 1.2f), mStone, env, true);
            Prim(PrimitiveType.Cylinder, "Pillar_R" + i, new Vector3(7, h, zs[i]), new Vector3(1.2f, h, 1.2f), mStone, env, true);
        }

        // Traps in the courtyard (red = danger)
        MakeTrap(hazards, "TrapZone_Courtyard_1", new Vector3(-3, 0.15f, 62), new Vector3(4, 0.3f, 4), "Spike trap!");
        MakeTrap(hazards, "TrapZone_Courtyard_2", new Vector3(3, 0.15f, 70), new Vector3(4, 0.3f, 4), "Spike trap!");
    }

    static void BuildTemple(Transform temple, Transform hazards)
    {
        // Facade with a door opening at x -2 .. 2
        Prim(PrimitiveType.Cube, "TempleWall_Left", new Vector3(-14, 3, 85), new Vector3(24, 6, 1), mDarkStone, temple, true);
        Prim(PrimitiveType.Cube, "TempleWall_Right", new Vector3(14, 3, 85), new Vector3(24, 6, 1), mDarkStone, temple, true);
        Prim(PrimitiveType.Cube, "TempleLintel", new Vector3(0, 5, 85), new Vector3(4, 2, 1), mStone, temple, true);
        Prim(PrimitiveType.Cylinder, "TemplePillar_L", new Vector3(-3.5f, 3, 83.5f), new Vector3(1.2f, 3, 1.2f), mStone, temple, true);
        Prim(PrimitiveType.Cylinder, "TemplePillar_R", new Vector3(3.5f, 3, 83.5f), new Vector3(1.2f, 3, 1.2f), mStone, temple, true);

        // Treasure chamber (z 85 .. 102)
        Prim(PrimitiveType.Cube, "ChamberFloor", new Vector3(0, -0.5f, 93.5f), new Vector3(16, 1, 17), mStone, temple, true);
        Prim(PrimitiveType.Cube, "ChamberWall_Left", new Vector3(-8.5f, 3, 93.5f), new Vector3(1, 6, 17), mDarkStone, temple, true);
        Prim(PrimitiveType.Cube, "ChamberWall_Right", new Vector3(8.5f, 3, 93.5f), new Vector3(1, 6, 17), mDarkStone, temple, true);
        Prim(PrimitiveType.Cube, "ChamberWall_Back", new Vector3(0, 3, 102.5f), new Vector3(18, 6, 1), mDarkStone, temple, true);

        // Locked stone door + trigger zone in front of it
        GameObject door = Prim(PrimitiveType.Cube, "StoneDoor", new Vector3(0, 2, 85), new Vector3(3.9f, 4, 0.9f), mWood, temple, true);

        GameObject zone = new GameObject("DoorTriggerZone");
        zone.transform.SetParent(temple, false);
        zone.transform.localPosition = new Vector3(0, 1.5f, 82.5f);
        BoxCollider bc = zone.AddComponent<BoxCollider>();
        bc.isTrigger = true;
        bc.size = new Vector3(6, 3, 4);
        TreasureDoor td = zone.AddComponent<TreasureDoor>();
        td.door = door.transform;
        td.requiredKeys = 1;

        // Treasure chest
        GameObject chest = new GameObject("TreasureChest");
        chest.transform.SetParent(temple, false);
        chest.transform.localPosition = new Vector3(0, 0, 97);
        Prim(PrimitiveType.Cube, "ChestBase", new Vector3(0, 0.4f, 0), new Vector3(1.6f, 0.8f, 1f), mChest, chest.transform, false, false);
        Prim(PrimitiveType.Cube, "ChestLid", new Vector3(0, 0.95f, 0), new Vector3(1.7f, 0.3f, 1.1f), mGold, chest.transform, false, false);
        Prim(PrimitiveType.Sphere, "Gem", new Vector3(0, 1.25f, 0), new Vector3(0.35f, 0.35f, 0.35f), mGold, chest.transform, false, false);
        BoxCollider cb = chest.AddComponent<BoxCollider>();
        cb.isTrigger = true;
        cb.center = new Vector3(0, 1, 0);
        cb.size = new Vector3(2.5f, 2, 2);
        chest.AddComponent<TreasureChest>();

        // Chamber lighting
        MakeLight("ChestGlow", new Vector3(0, 2.5f, 97), new Color(1f, 0.85f, 0.3f), 10f, 3f, temple);
        MakeLight("Torch_L", new Vector3(-7, 3, 90), new Color(1f, 0.55f, 0.2f), 9f, 2.5f, temple);
        MakeLight("Torch_R", new Vector3(7, 3, 90), new Color(1f, 0.55f, 0.2f), 9f, 2.5f, temple);
        Prim(PrimitiveType.Sphere, "Flame_L", new Vector3(-7, 3, 90), new Vector3(0.4f, 0.4f, 0.4f), mKey, temple, false, false);
        Prim(PrimitiveType.Sphere, "Flame_R", new Vector3(7, 3, 90), new Vector3(0.4f, 0.4f, 0.4f), mKey, temple, false, false);
    }

    static void MakeLight(string name, Vector3 pos, Color color, float range, float intensity, Transform parent)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        Light l = go.AddComponent<Light>();
        l.type = LightType.Point;
        l.color = color;
        l.range = range;
        l.intensity = intensity;
    }

    static void BuildJungleDecor(Transform env)
    {
        System.Random rng = new System.Random(42);

        // Trees (kept away from the path, the ravine and the pillars)
        for (int i = 0; i < 80; i++)
        {
            float side = rng.Next(0, 2) == 0 ? -1f : 1f;
            float x = side * (7f + (float)rng.NextDouble() * 17f);
            float z = -8f + (float)rng.NextDouble() * 92f;
            if (z > 38f && z < 55f) continue;
            if (z >= 53f && Mathf.Abs(x) < 13f) continue;

            float h = 5f + (float)rng.NextDouble() * 4f;
            Prim(PrimitiveType.Cylinder, "TreeTrunk", new Vector3(x, h / 2f, z), new Vector3(0.7f, h / 2f, 0.7f), mTrunk, env, false, true);
            Prim(PrimitiveType.Sphere, "TreeCanopy", new Vector3(x, h + 0.8f, z), new Vector3(4.5f, 3.5f, 4.5f), (i % 2 == 0) ? mLeaf : mLeaf2, env, false, false);
            if (i % 3 == 0)
                Prim(PrimitiveType.Cylinder, "Vine", new Vector3(x + 1.6f, h - 1f, z), new Vector3(0.08f, 1.6f, 0.08f), mLeaf2, env, false, false);
        }

        // Bushes along the path edges
        for (int i = 0; i < 45; i++)
        {
            float side = rng.Next(0, 2) == 0 ? -1f : 1f;
            float x = side * (3.5f + (float)rng.NextDouble() * 6f);
            float z = -8f + (float)rng.NextDouble() * 92f;
            if (z > 38f && z < 55f) continue;
            if (z >= 53f && Mathf.Abs(x) < 9f) continue;
            if (Mathf.Abs(x - 6.5f) < 3f && Mathf.Abs(z - 30f) < 3f) continue; // keep the trap visible
            Prim(PrimitiveType.Sphere, "Bush", new Vector3(x, 0.4f, z), new Vector3(1.4f, 0.9f, 1.4f), mLeaf2, env, false, false);
        }

        // Rocks in the forest section
        for (int i = 0; i < 25; i++)
        {
            float side = rng.Next(0, 2) == 0 ? -1f : 1f;
            float x = side * (4f + (float)rng.NextDouble() * 10f);
            float z = -8f + (float)rng.NextDouble() * 44f;
            if (Mathf.Abs(x + 8f) < 3f && z > 26f && z < 34f) continue; // keep the stone steps clear
            if (Mathf.Abs(x - 6.5f) < 3f && Mathf.Abs(z - 30f) < 3f) continue;
            float s = 0.8f + (float)rng.NextDouble() * 1f;
            Prim(PrimitiveType.Sphere, "Rock", new Vector3(x, s * 0.25f, z), new Vector3(s * 1.4f, s * 0.9f, s * 1.1f), mDarkStone, env, true, true);
        }
    }

    // ------------------------------------------------------------------ collectibles

    static void BuildCollectibles(Transform items)
    {
        // Coins along the route (forest path, bridge, courtyard, chamber)
        Vector3[] coins =
        {
            new Vector3(0,1,8), new Vector3(0,1,12), new Vector3(0,1,16),
            new Vector3(-2,1,26), new Vector3(2,1,26), new Vector3(0,1,30), new Vector3(0,1,38),
            new Vector3(0,1.4f,42), new Vector3(0,1.4f,46), new Vector3(0,1.4f,50),
            new Vector3(0,1,57), new Vector3(0,1,66), new Vector3(-4,1,66), new Vector3(4,1,76),
            new Vector3(-4,1,78), new Vector3(0,1,74), new Vector3(4,1,58),
            new Vector3(-3,1,90), new Vector3(3,1,90), new Vector3(0,1,93)
        };
        foreach (Vector3 p in coins) MakeCollectible(items, CollectibleType.Coin, p, "");

        // Clues
        MakeCollectible(items, CollectibleType.Clue, new Vector3(4, 1, 24), "Clue 1/2: An old bridge leads to the ancient courtyard.");
        MakeCollectible(items, CollectibleType.Clue, new Vector3(10, 1, 62), "Clue 2/2: The temple key is hidden among the pillars.");

        // The temple key
        MakeCollectible(items, CollectibleType.Key, new Vector3(-10, 1.2f, 73), "");
    }

    static void MakeCollectible(Transform parent, CollectibleType type, Vector3 pos, string message)
    {
        GameObject root = new GameObject(type.ToString());
        root.transform.SetParent(parent, false);
        root.transform.position = pos;

        SphereCollider sc = root.AddComponent<SphereCollider>();
        sc.isTrigger = true;
        sc.radius = 0.9f;

        Collectible c = root.AddComponent<Collectible>();
        c.type = type;
        c.message = message;

        Transform t = root.transform;
        switch (type)
        {
            case CollectibleType.Coin:
                c.points = 10;
                Prim(PrimitiveType.Cylinder, "CoinVisual", Vector3.zero, new Vector3(0.6f, 0.05f, 0.6f), mGold, t, false, false)
                    .transform.localRotation = Quaternion.Euler(90, 0, 0);
                break;
            case CollectibleType.Key:
                c.points = 50;
                Prim(PrimitiveType.Cylinder, "KeyHead", new Vector3(0, 0.35f, 0), new Vector3(0.5f, 0.06f, 0.5f), mKey, t, false, false)
                    .transform.localRotation = Quaternion.Euler(90, 0, 0);
                Prim(PrimitiveType.Cube, "KeyShaft", new Vector3(0, -0.1f, 0), new Vector3(0.12f, 0.7f, 0.1f), mKey, t, false, false);
                Prim(PrimitiveType.Cube, "KeyTooth", new Vector3(0.12f, -0.35f, 0), new Vector3(0.25f, 0.1f, 0.1f), mKey, t, false, false);
                break;
            case CollectibleType.Clue:
                c.points = 25;
                Prim(PrimitiveType.Cylinder, "ScrollVisual", Vector3.zero, new Vector3(0.22f, 0.35f, 0.22f), mScroll, t, false, false)
                    .transform.localRotation = Quaternion.Euler(0, 0, 90);
                break;
        }
    }

    // ------------------------------------------------------------------ player & camera

    static GameObject BuildPlayer()
    {
        GameObject p = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        p.name = "Player";
        p.tag = "Player";
        p.transform.position = new Vector3(0, 1.05f, 0);
        p.GetComponent<Renderer>().sharedMaterial = mPlayer;

        Rigidbody rb = p.AddComponent<Rigidbody>();
        rb.mass = 1f;
        rb.useGravity = true;
        rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;

        p.AddComponent<PlayerController>();

        // Little explorer details so you can see which way you are facing
        Prim(PrimitiveType.Cube, "Face", new Vector3(0, 0.55f, 0.42f), new Vector3(0.35f, 0.2f, 0.3f), mSkin, p.transform, false, false);
        Prim(PrimitiveType.Cylinder, "HatBrim", new Vector3(0, 0.82f, 0), new Vector3(0.95f, 0.03f, 0.95f), mHat, p.transform, false, false);
        Prim(PrimitiveType.Cylinder, "HatTop", new Vector3(0, 0.92f, 0), new Vector3(0.5f, 0.1f, 0.5f), mHat, p.transform, false, false);
        return p;
    }

    static void SetupCamera(Transform player)
    {
        Camera cam = Camera.main;
        if (cam == null)
        {
            GameObject g = GameObject.Find("Main Camera");
            if (g != null) cam = g.GetComponent<Camera>();
        }
        if (cam == null) return;

        CameraFollow follow = cam.gameObject.AddComponent<CameraFollow>();
        follow.target = player;
        cam.transform.position = player.position + follow.offset;
        cam.transform.LookAt(player.position + Vector3.up * 0.5f);
        cam.farClipPlane = 300f;
    }
}
