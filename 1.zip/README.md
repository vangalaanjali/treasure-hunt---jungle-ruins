# Treasure Hunt – Jungle Ruin (Unity 3D)

Implements the design in the PDF: explorer character, jungle environment, broken bridge, fallen logs,
traps, coins / keys / clues, camera follow, HUD, locked temple door, treasure chamber, Game Over and Victory.

## Setup (about 2 minutes)

1. In Unity Hub create a new project: **Universal 3D (URP)** (or any 3D template), name it `TreasureHuntJungleRuin`.
   Works on Unity 2021 LTS through Unity 6.
2. Close Unity or leave it open, then copy the **Assets** folder from this zip into your project's folder
   (merge when asked).
3. Back in Unity, wait for scripts to compile, then choose the menu
   **Treasure Hunt > Build Jungle Ruin Level**.
   - This creates the Scenes / Scripts / Materials / Prefabs / Models folders, the `Ground` tag,
     all materials, and the full level, and saves `Assets/Scenes/JungleRuinLevel.unity`.
   - If your project only uses the new Input System, the tool switches Active Input Handling to
     "Both" and asks you to restart the editor (the scripts use the legacy Input Manager, as in the PDF).
4. Press **Play**.

## Controls

| Key | Action |
|-----|--------|
| W A S D / Arrow keys | Move |
| Space | Jump |
| R | Restart |

## How to play

1. Collect coins on the forest path and jump the fallen logs (Clue 1 is near the path).
2. Cross the **broken bridge** by jumping between planks. Falling = Game Over.
3. In the **ancient courtyard** avoid the red spike traps, pick up Clue 2 and find the **key** hidden behind the left pillars.
4. Walk to the **temple door**. With the key it slides open ("Door unlocked!").
5. Enter the **treasure chamber** and touch the chest: **Treasure Found!**

## Scripts (Assets/Scripts)

| Script | Purpose (PDF step) |
|--------|--------------------|
| PlayerController | Rigidbody movement, Space to jump, ground check (Step 4) |
| CameraFollow | Smooth follow camera behind the player (Step 9) |
| Collectible | Coins add score; keys and clues for progress (Step 6) |
| Hazard | Pits, traps and kill plane trigger Game Over (Step 7) |
| TreasureDoor | Checks for the key and opens the door (Step 8) |
| TreasureChest | Victory trigger (Step 8) |
| GameManager | Score, keys, clues, game state, HUD messages, restart (Step 10) |

`Assets/Editor/JungleRuinBuilder.cs` automates Steps 1–3, 5–8 and 10 (scene construction).

## Testing checklist (from the PDF)

Movement and jump, camera follow, collectibles disappear and update the HUD, bridge crossable,
hazards cause Game Over, door reacts to the key, chest triggers Victory, **R** resets everything.

## Customizing

Select the objects created by the builder and tweak in the Inspector: `moveSpeed` / `jumpForce` on Player,
`offset` on Main Camera, `requiredKeys` on DoorTriggerZone, `points` on any Collectible.
Ideas from the PDF for expansion: sound effects, animations, moving traps, checkpoints, more levels.
